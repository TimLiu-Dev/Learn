package pricing;

import java.util.List;

public final class Pricing {
    private static final int BIG_ORDER_CENTS = 5000;
    private static final int BIG_ORDER_MEMBER_PERCENT = 10;
    private static final int MEMBER_PERCENT = 5;
    private static final int COUPON_CAP_CENTS = 2000;
    private static final int FREE_SHIPPING_FROM_CENTS = 3500;
    private static final int SHIPPING_CENTS = 499;

    public static int price(List<int[]> items, String coupon, boolean member) {
        int totalCents = subtotalCents(items);
        if (member) {
            if (totalCents > BIG_ORDER_CENTS) {
                totalCents = percentOff(totalCents, BIG_ORDER_MEMBER_PERCENT, Integer.MAX_VALUE);
            } else {
                totalCents = percentOff(totalCents, MEMBER_PERCENT, Integer.MAX_VALUE);
            }
        }
        if (coupon != null) {
            if (coupon.equals("SAVE10")) {
                totalCents = percentOff(totalCents, 10, COUPON_CAP_CENTS);
            } else if (coupon.equals("SAVE20")) {
                totalCents = percentOff(totalCents, 20, COUPON_CAP_CENTS);
            } else if (coupon.startsWith("FLAT")) {
                int dollars;
                try {
                    dollars = Integer.parseInt(coupon.substring(4));
                } catch (NumberFormatException e) {
                    dollars = 0;
                }
                totalCents = totalCents - dollars * 100;
                if (totalCents < 0) totalCents = 0;
            }
        }
        if (totalCents < FREE_SHIPPING_FROM_CENTS) {
            if (!member) totalCents = totalCents + SHIPPING_CENTS;
        }
        return totalCents;
    }

    private static int subtotalCents(List<int[]> items) {
        int cents = 0;
        for (int[] item : items) {
            int quantity = item[0], unitCents = item[1];
            if (quantity <= 0) continue;
            cents += quantity * unitCents;
        }
        return cents;
    }

    private static int percentOff(int cents, int percent, int capCents) {
        return cents - Math.min(cents * percent / 100, capCents);
    }
}
